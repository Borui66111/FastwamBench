# Changelog

## 2026-10-08 — New-server warm-start handoff

**Issue**
The project is moving from a disconnected/original server and a dependency-light prototype to a new GPU server. A fresh coding agent would otherwise need to reconstruct research intent, upstream code paths, metric definitions, installation order, and validation gates from chat history.

**Reason**
FastBench spans research design, FastWAM inference, LIBERO-Safety/MuJoCo simulation, intervention mechanics, evidence logging, and benchmark metrics. Missing context at handoff can produce scientifically invalid shortcuts (e.g. modifying the world before the action chunk is planned, conflating toy tests with real results, or reporting only task success).

**Fix**
Added:
- `AGENTS.md`: concise always-on research/engineering rules;
- `WARM_START.md`: detailed server setup, execution gates, code hook points, evidence schema, metrics, failure triage, and definition of done;
- self-contained copies of the current `STATE.md`, `REQUIREMENTS.md`, `INTEGRATION_PLAN.md`, prototype code/tests, and toy results.

**Verification**
- Cross-checked FastWAM upstream environment/evaluation path and current released checkpoint workflow.
- Cross-checked LIBERO-Safety installation/drop-in package behavior and benchmark registry structure.
- Reconciled handoff against existing FastBench prototype APIs and verified state documents.
- Handoff design follows a short always-loaded `AGENTS.md` plus detailed task/state docs to reduce agent rediscovery and instruction overload.
