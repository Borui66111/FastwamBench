# FastBench State

## Current status
- [x] Research framing frozen to H1/H2/H3 for MVP.
- [x] Official FastWAM LIBERO rollout entry point identified: `experiments/libero/eval_libero_single.py::run_single_episode`.
- [x] LIBERO-Safety benchmark registry identified: `libero/libero/benchmark/vla_safety_task_map.py`.
- [x] LIBERO-Safety dynamic-motion primitives identified: `LinearMotionGenerator`, `CircularMotionGenerator` in `libero/libero/envs/utils.py`.
- [x] Local dependency-light benchmark runner prototype created.
- [ ] Execute actual LIBERO-Safety environment locally.
- [ ] Connect official FastWAM checkpoint.
- [ ] Add explicit future-video / state consistency metric.

## Environment limitation
The current local execution environment does not have `libero`, `mujoco`, or `robosuite` installed, and direct GitHub cloning is network-blocked. Public source inspection is being done through the GitHub connector. Therefore the current executable test validates the benchmark runner contract, not MuJoCo behavior or FastWAM model performance.

## Next integration target
Port the generic intervention/recording hooks into FastWAM's `run_single_episode()` while using LIBERO-Safety as the installed `libero` package.

## Locally verified prototype result
A deterministic target-displacement test was executed with two replanning horizons:

- `replan_steps=1`: intervention step 2; first replan after intervention step 3; stale actions = 1; recovered successfully.
- `replan_steps=4`: intervention step 2; first replan after intervention step 4; stale actions = 2; recovered successfully, but later.

This is a toy contract test only; it verifies the definitions and runner mechanics, not a robotics conclusion.
