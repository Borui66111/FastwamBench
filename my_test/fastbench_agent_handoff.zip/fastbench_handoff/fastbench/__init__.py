"""FastBench prototype package."""
